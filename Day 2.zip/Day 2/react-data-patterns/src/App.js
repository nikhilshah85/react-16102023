import logo from './logo.svg';
import './App.css';

function App() {


    var bankAccounts = [
        {accNo:101, accName:'Karan',accType:'Savings', accBalance:5000,accIsActive:true },
        {accNo:102, accName:'Reema',accType:'Current', accBalance:2000,accIsActive:true },
        {accNo:103, accName:'Kriti',accType:'Savings', accBalance:3000,accIsActive:true },
        {accNo:104, accName:'Sahil',accType:'Current', accBalance:5000,accIsActive:false },
        {accNo:105, accName:'Mohan',accType:'Savings', accBalance:7000,accIsActive:true },
        {accNo:106, accName:'Rohan',accType:'Savings', accBalance:9000,accIsActive:true },
        {accNo:107, accName:'Nidhi',accType:'Savings', accBalance:12000,accIsActive:true },
        {accNo:108, accName:'Sukesh',accType:'Current', accBalance:700,accIsActive:false },

    ]



  return (
   <div>
        <h2 className='App'> Banking Details </h2>

        <table border={1}>
          <tr>
            <td> Account No</td>
            <td> Account Name</td>
            <td> Account Type</td>
            <td> Account Balance</td>
            <td> Account Status</td>
          </tr>

          { bankAccounts.map(acc => <tr>
              <td> { acc.accNo } </td>
              <td> { acc.accName } </td>
              <td> { acc.accType } </td>
              <td> { acc.accBalance } </td>
              <td className={acc.accIsActive?'greenCell':'redCell'}> { acc.accIsActive? 'Active':'In-Active' } </td>

          </tr>) }
        </table>
   </div>
  );
}

export default App;
