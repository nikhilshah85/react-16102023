import logo from './logo.svg';
import './App.css';
import HeaderComponent from './components/header';
import ContentComponent from './components/content';
import EmployeeDetails from './components/employeeDetails';

function App() {
  return (
    <div>

      
      <ContentComponent></ContentComponent>
      <HeaderComponent></HeaderComponent>

      <EmployeeDetails></EmployeeDetails>



    </div>
  );
}

export default App;
