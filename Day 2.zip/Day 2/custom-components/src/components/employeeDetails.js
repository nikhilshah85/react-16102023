


function EmployeeDetails(){

var greetMessage = 'Hello and welcome to Employee Component';

function greetMessageFunction()
{
    alert('Hello ');
}


return(<div>
    <h2> {greetMessage} </h2>
    <button onClick={greetMessageFunction} >Click Me</button>
</div>)


}

export default EmployeeDetails;