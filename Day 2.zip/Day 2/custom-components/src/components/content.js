
function ContentComponent(){

    var developerDetails = {
        developerName: 'Nikhil',
        teamSize : 20,
        isProjectLive : false,
        technologiesUsed : 'React'

    }

    return(<div className="contentComponentDiv">
        <h4> Developer : {  developerDetails.developerName }</h4>
        <h4> Developer : {  developerDetails.teamSize }</h4>
        <h4> Developer : {  developerDetails.technologiesUsed }</h4>
        <h4> Developer : {  developerDetails.isProjectLive }</h4>

    </div>)

}

export default ContentComponent;