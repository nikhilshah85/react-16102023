import '../App.css'


function HeaderComponent(){


        var logo = "This is the logo in Header Component";
        var title = "This is the very first component I am createing in REACT"

            return(<div className='App'>
                    <h2> {logo}</h2>
                    <p> { title }</p>

            </div>)      



}


export default HeaderComponent;