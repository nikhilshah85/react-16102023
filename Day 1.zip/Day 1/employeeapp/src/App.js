import './App.css';

function App() {


  var firstName = 'Nikhil';
  var lastName = 'Shah';
  var salary = 20000;

  var technologies = ['React','Angular','.Net','Azure','SQL Server','PowerBi']

  var contactDetails = {
    city:'Mumbai',
    email:'nikhil@hotmail.com',
    phone:897867,
    emergency:986857
  }

  return (
    <div>
      <h1 className='App'> Employee Management App </h1>

      <section className='developerIntro'>
      <h3> First Name : { firstName }</h3>
      <h3> Last Name : { lastName }</h3>
      <h3> Salary : { salary } </h3>
      <h3> Bonus : { salary * 0.1 }</h3>

    


      </section>

      <ul>
        { technologies.map( t => <li> {t}</li>) }
      </ul>

      <select>
        {technologies.map(t => <option> {t} </option>)}
      </select>

      <div className='contactDetails'>
        <h2> Contact Details </h2>
        <h4> City : { contactDetails.city }</h4>
        <h4> Email :{ contactDetails.email }</h4>
        <h4> Call : { contactDetails.phone }</h4>
        <h4> Emergency : { contactDetails.emergency }</h4>
      </div>

    
    </div>
  );
}

export default App;
