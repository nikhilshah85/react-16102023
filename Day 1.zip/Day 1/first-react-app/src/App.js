import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
        <h1> Welcome to React World </h1>

        <p>Hello this is my very first react app</p>

        <h2> This is the default component in action and this is looking nice as of now </h2>
    </div>
  );
}

export default App;
